﻿using Dapper;
using System.Data;
using WebApplication8.model;
using WebApplication8.Contracts;

namespace WebApplication8.service
{
    public class userservice : Iuserservice
    {
        private readonly IDbConnection _dbConnection;

        public userservice(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<string> Registeruser(int id, string name, string password)
        {
            var existinguser = await _dbConnection.QueryFirstOrDefaultAsync<user>(
                "SELECT name FROM users WHERE id = @Id",
                new { Id = id });

            if (existinguser != null)
            {
                return "User already exists.";
            }

            var result = await _dbConnection.ExecuteAsync(
                "INSERT INTO users (id,name,password,role) VALUES (@id,@name,@password,'user')",
                new
                {
                    id,
                    name,
                    password
                });

            return result > 0 ? "User registered successfully." : "Failed to register user.";
        }

        public async Task<user> loginuser(string name, string password)
        {
            var user = await _dbConnection.QueryFirstOrDefaultAsync<user>(
                "SELECT * FROM users WHERE name = @name AND password = @password",
                new { name, password });

            return user; 
        }
    }
}