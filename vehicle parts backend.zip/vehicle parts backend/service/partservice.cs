﻿using System.Data;
using System.Data.SqlClient;
using WebApplication8.Contracts;
using WebApplication8.model;

namespace WebApplication8.service
{
    public class partservice : Ipartservice
    {
        private readonly string _connection;

        public partservice(IConfiguration configuration)
        {
            _connection = configuration.GetConnectionString("DefaultConnection");
        }

        public List<vehicles> SearchParts(string name)
        {
            List<vehicles> parts = new List<vehicles>();

            using (SqlConnection con = new SqlConnection(_connection))
            {
                string query = "SELECT * FROM vehicleparts WHERE partname LIKE @name";

                SqlCommand command = new SqlCommand(query, con);
                command.Parameters.AddWithValue("@name", "%" + name + "%");

                con.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    parts.Add(new vehicles
                    {
                        id = (int)reader["id"],
                        partname = reader["partname"].ToString(),
                        vehicle = reader["vehicle"].ToString(),
                        price = (int)reader["price"]
                    });
                }
            }

            return parts;
        }

        public void AddPart(vehicles part)
        {
            using (SqlConnection con = new SqlConnection(_connection))
            {
                string query = "INSERT INTO vehicleparts (partname,vehicle,price) VALUES (@name,@vehicle,@price)";

                SqlCommand command = new SqlCommand(query, con);

                command.Parameters.AddWithValue("@name", part.partname);
                command.Parameters.AddWithValue("@vehicle", part.vehicle);
                command.Parameters.AddWithValue("@price", part.price);

                con.Open();
                command.ExecuteNonQuery();
            }
        }
        public List<vehicles> GetAllParts()
        {
            List<vehicles> parts = new List<vehicles>();

            using (SqlConnection con = new SqlConnection(_connection))
            {
                string query = "SELECT * FROM vehicleparts";

                SqlCommand command = new SqlCommand(query, con);

                con.Open();

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    parts.Add(new vehicles
                    {
                        id = (int)reader["id"],
                        partname = reader["partname"].ToString(),
                        vehicle = reader["vehicle"].ToString(),
                        price = (int)reader["price"]
                    });
                }
            }

            return parts;
        }
    }
}
