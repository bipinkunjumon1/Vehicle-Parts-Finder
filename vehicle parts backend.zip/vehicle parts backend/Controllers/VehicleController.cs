﻿using Microsoft.AspNetCore.Mvc;
using WebApplication8.Contracts;
using WebApplication8.model;

namespace WebApplication8.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class vehiclecontroller : ControllerBase
    {
        private readonly Ipartservice _service;

        public vehiclecontroller(Ipartservice service)
        {
            _service = service;
        }

        [HttpGet("search")]
        public IActionResult Search(string name)
        {
            var result = _service.SearchParts(name);
            return Ok(result);
        }

        [HttpPost]
        public IActionResult AddPart([FromBody] vehicles part)
        {
            _service.AddPart(part);
            return Ok("Part Added Successfully");
        }

        [HttpGet("all")]
        public IActionResult GetAllParts()
        {
            var result = _service.GetAllParts();
            return Ok(result);
        }
    }
}