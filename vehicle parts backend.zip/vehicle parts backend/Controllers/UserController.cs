﻿using Microsoft.AspNetCore.Mvc;
using WebApplication8.Contracts;

namespace WebApplication8.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : Controller
    {
        private readonly Iuserservice _userservice;

        public UserController(Iuserservice userservice)
        {
            _userservice = userservice;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(int id, string user, string password)
        {
            var result = await _userservice.Registeruser(id, user, password);
            return Ok(result);
        }

        [HttpPost("login")]
        public async Task<IActionResult> login(string name, string password)
        {
            var result = await _userservice.loginuser(name, password);

            if (result == null)
                return Unauthorized("Invalid username or password");

            return Ok(result); 
        }
    }
}