﻿namespace WebApplication8.model
{
    public class vehicles
    {
        public int id { get; set; }

        public string partname { get; set; }

        public string vehicle { get; set; }

        public int price { get; set; }
    }
}