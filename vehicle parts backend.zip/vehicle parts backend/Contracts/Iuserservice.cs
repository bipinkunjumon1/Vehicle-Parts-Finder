﻿
using WebApplication8.model;

namespace WebApplication8.Contracts
{
    public interface Iuserservice
    {
        Task<string> Registeruser(int id, string name, string password);

    

        Task<user> loginuser(string name, string password);
    }
}
