﻿using WebApplication8.model;

namespace WebApplication8.Contracts
{
    public interface Ipartservice
    {
        List<vehicles> SearchParts(string name);

        void AddPart(vehicles part);

        List<vehicles> GetAllParts();
    }
}