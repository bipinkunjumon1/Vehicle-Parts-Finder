create database userss;
use userss;
create table users(id int primary key, name varchar (20), password varchar(20));

select*from users;


create table vehicleparts(id int primary key, partname varchar(20),vehicle varchar(20),price int);

create table vehicleparts(id int identity(1,1) primary key,partname varchar(20),
vehicle varchar(20),
price int
);

alter table users add role varchar(20);
INSERT INTO users(id,name,password,role)
VALUES (3,'admin','123','admin');


select* from vehicleparts;